Click "Stata_101.doc" to start the training

Be sure to extract all files from the zipped folder before beginning the training. 

