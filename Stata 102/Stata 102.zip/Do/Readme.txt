The files in this folder are not meant to be used by trainees.
The training start page is "India 2013 High Intermediate.smcl", in the folder above this one.
To get started, double-click "India 2013 High Intermediate.smcl" or
open it from within Stata through File � View.

Matt White
Innovations for Poverty Action
mwhite@poverty-action.org
