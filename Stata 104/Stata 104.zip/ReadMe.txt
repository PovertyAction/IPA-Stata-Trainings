The training start page is "Stata 104.smcl".
To get started, double-click "Stata 104.smcl" or
open it from within Stata through File � View.

Be sure to extract all files from the zipped folder before beginning the training. 
