The files in this folder are not meant to be used by trainees.
The training start page is "Stata 103 smcl", in the folder above this one.
To get started, double-click "Stata 103.smcl" or
open it from within Stata through File � View.

Harrison Diamond Pollock
Innovations for Poverty Action
hpollock@poverty-action.org