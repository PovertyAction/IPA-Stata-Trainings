The training start page is "Stata 103.smcl".
To get started, double-click "Stata 103.smcl" or
open it from within Stata through File � View.

Be sure to extract all files from the zipped folder before beginning the training. 
